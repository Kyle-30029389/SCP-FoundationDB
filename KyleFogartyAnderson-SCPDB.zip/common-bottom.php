    <script src="scripts/script.js"></script><!--Link External Java Script-->
   <footer >Kyle Fogarty-Anderson 30029389</footer>
</body>
</html>
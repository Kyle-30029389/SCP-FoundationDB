<div class="background1" style="position: absolute;"></div> <!--StaticBackground-->
<div id="change" class="background2" style="position: absolute;"></div>  <!--Changing Background-->
<?php
    $link = mysqli_connect( 'localhost', 
                            'user', 
                            'p*1Ku?25g,Yy', 
                            'a3002938_SCPData' ); 
?>
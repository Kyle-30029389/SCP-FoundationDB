<?php
include("common-top.php");
include("nav.php"); 
include("background.php"); 
include("form.php"); 
include("common-bottom.php"); 
?>